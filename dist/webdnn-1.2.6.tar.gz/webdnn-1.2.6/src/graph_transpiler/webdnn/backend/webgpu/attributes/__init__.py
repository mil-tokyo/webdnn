from webdnn.backend.webgpu.attributes import lstm_optimized
