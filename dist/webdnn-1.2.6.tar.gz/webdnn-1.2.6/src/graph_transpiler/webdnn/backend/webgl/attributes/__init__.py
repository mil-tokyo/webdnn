from webdnn.backend.webgl.attributes import channel_mode
