# WebGL Backend

## TODO

- WebGL Context release

    Browser cannot hold so many rendering context. It becomes a problem during unit tests.

- Kernel Concatenation

- Implement All Kernels
    - embedding
    - local_response_normalization
    - lstm
    - zero_padding_1d
