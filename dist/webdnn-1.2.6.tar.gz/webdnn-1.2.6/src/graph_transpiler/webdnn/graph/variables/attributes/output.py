from webdnn.graph.attribute import Attribute


class Output(Attribute):
    """Output
    Attribute for output variable of graph
    """
    pass
