from webdnn.backend import code_generator
from webdnn.backend import fallback
from webdnn.backend import interface
from webdnn.backend import webassembly
from webdnn.backend import webgl
from webdnn.backend import webgpu
# alias
from webdnn.backend.interface.generator import generate_descriptor, backend_names
