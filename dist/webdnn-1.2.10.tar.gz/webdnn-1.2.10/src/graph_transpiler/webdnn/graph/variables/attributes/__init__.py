from webdnn.graph.variables.attributes import input
from webdnn.graph.variables.attributes import output
