from webdnn.graph.variables import attributes
from webdnn.graph.variables import constant_variable
