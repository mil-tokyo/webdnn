from webdnn.backend.interface import generator
from webdnn.backend.interface import graph_descriptor
