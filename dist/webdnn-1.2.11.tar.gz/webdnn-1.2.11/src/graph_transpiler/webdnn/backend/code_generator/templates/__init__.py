from webdnn.backend.code_generator.templates import elementwise
