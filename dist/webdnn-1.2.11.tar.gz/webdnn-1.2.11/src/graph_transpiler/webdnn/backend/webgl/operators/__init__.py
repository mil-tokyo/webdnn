from webdnn.backend.webgl.operators import convert_r_to_rgba
from webdnn.backend.webgl.operators import convert_rgba_to_r
