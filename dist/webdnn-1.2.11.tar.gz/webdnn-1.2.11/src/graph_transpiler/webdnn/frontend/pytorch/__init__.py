from webdnn.frontend.pytorch import converter
# alias
from webdnn.frontend.pytorch.converter import PyTorchConverter
