from webdnn.graph.attribute import Attribute


class Input(Attribute):
    """Input
    Attribute for input variable of graph
    """
    pass
