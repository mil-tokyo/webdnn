from webdnn.frontend.onnx.defs import generator
from webdnn.frontend.onnx.defs import logical
from webdnn.frontend.onnx.defs import math
from webdnn.frontend.onnx.defs import nn
from webdnn.frontend.onnx.defs import reduction
from webdnn.frontend.onnx.defs import rnn
from webdnn.frontend.onnx.defs import tensor
