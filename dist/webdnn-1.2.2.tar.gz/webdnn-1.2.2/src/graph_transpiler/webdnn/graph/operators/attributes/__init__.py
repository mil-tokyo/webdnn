from webdnn.graph.operators.attributes import associative
from webdnn.graph.operators.attributes import tensorwise
from webdnn.graph.operators.attributes import commutative
from webdnn.graph.operators.attributes import inplace
