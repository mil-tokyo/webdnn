from webdnn.frontend.onnx import converter
from webdnn.frontend.onnx import defs
# alias
from webdnn.frontend.onnx.converter import ONNXConverter
