from webdnn.backend.webgl import attributes
from webdnn.backend.webgl import generator
from webdnn.backend.webgl import graph_descriptor
from webdnn.backend.webgl import kernel
from webdnn.backend.webgl import kernels
from webdnn.backend.webgl import operators
from webdnn.backend.webgl import optimize_rules
from webdnn.backend.webgl import uniform_injector
