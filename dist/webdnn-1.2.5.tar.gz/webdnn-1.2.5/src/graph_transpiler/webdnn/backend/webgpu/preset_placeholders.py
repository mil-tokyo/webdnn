from webdnn.graph.placeholder import Placeholder

MAX_THREADS_PER_THREADGROUP = Placeholder(label="__MAX_THREADS_PER_THREADGROUP__")
